import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-postavke-profila',
  templateUrl: './postavke-profila.component.html',
  styleUrls: ['./postavke-profila.component.css']
})
export class PostavkeProfilaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
