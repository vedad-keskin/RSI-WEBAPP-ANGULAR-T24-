﻿namespace FIT_Api_Examples.Data
{
    public class Predmet
    {
        public int ID { get; set; }
        public string Naziv { get; set; }
        public string Sifra { get; set; }
        public float ECTS { get; set; }

    }
}
