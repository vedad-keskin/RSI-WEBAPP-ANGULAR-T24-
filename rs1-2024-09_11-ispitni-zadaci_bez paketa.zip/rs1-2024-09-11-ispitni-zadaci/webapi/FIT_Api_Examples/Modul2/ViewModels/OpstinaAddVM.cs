﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FIT_Api_Examples.Modul2.ViewModels
{
    public class OpstinaAddVM
    {
        public string opis { get; set; }
        public int drzava_id { get; set; }
    }
}
