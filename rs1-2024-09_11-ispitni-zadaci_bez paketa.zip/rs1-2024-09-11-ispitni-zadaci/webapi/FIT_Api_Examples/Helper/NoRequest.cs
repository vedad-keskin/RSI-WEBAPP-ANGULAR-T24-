﻿namespace FIT_Api_Example.Helper;

public class NoRequest
{
}