﻿namespace FIT_Api_Examples.Helper
{
    public class CmbStavke
    { 
        public int id { get; set; }
        public string opis { get; set; }
    }
}
