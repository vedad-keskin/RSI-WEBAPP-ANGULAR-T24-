﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FIT_Api_Examples.Modul0_Autentifikacija.ViewModels
{
    public class LoginVM
    {
        public string korisnickoIme { get; set; }
        public string lozinka { get; set; }
    }
}
