﻿namespace FIT_Api_Example.Endpoints.IspitEndpoints.Obrisi;

public class IspitObrisiResponse
{
       
}