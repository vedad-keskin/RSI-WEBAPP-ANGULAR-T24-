﻿namespace FIT_Api_Example.Endpoints.IspitEndpoints.Obrisi;

public class IspitObrisiRequest
{
    public int IspitID{ get; set; }
}