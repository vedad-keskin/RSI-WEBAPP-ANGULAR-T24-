﻿namespace FIT_Api_Example.Endpoints.IspitEndpoints.Dodaj;

public class IspitDodajResponse
{
    public int IspitId { get; set; }
}